using System.Collections.Generic;

namespace IndiaSEBIDailyHeadlines
{
    internal class PublicationData
    {
        public List<Story> Stories { get; set; }
        public PublicationData()
        {
            Stories = new List<Story>();
        }
    }

    internal class Story
    {
        public string Type { get; set; }
        public string Text { get; set; }
        public string Headline { get; set; }
    }
}
