using System;
using System.Globalization;
using System.Net;
using AutomationCore;

namespace IndiaSEBIDailyHeadlines
{
    public class Main : AutomationClient
    {
        public override SourceStore LoadSourceStore(Config config)
        {
            var storeInstance = new MySourceStore(this.GetType().Assembly.Location, config);
            try
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11;
                ServicePointManager.ServerCertificateValidationCallback += (_, _, _, _) => true;

                string runDateRaw = ConfigHelper.GetValue(Constants.ForceFilingDate, store);
                string runDateRaw = ConfigHelper.GetValue(Constants.ForceFilingDate, store);
                string runDateRaw = ConfigHelper.GetValue(Constants.ForceFilingDate, store);
            
                storeInstance.CircularKeywords = Helper.GetConfigValue(Constants.CIRCULAR_KEYWORDS, storeInstance).Replace(" ", @"\W+");
                storeInstance.PressReleaseKeywords = Helper.GetConfigValue(Constants.PRESS_RELEASE_KEYWORDS, storeInstance).Replace(" ", @"\W+");

                storeInstance.RunDate = !string.IsNullOrWhiteSpace(runDateValue)
                    ? DateTime.ParseExact(runDateValue, "dd-MM-yyyy", CultureInfo.InvariantCulture)
                    : Helper.GetLocalDate(Constants.TimeZone);

                string forceSwitch = Helper.GetConfigValue(Constants.forceFilingSwitch, storeInstance).Trim().ToLowerInvariant();

                if (forceSwitch == "on")
                {
                    string ordersUrl = Helper.GetConfigValue(Constants.forceFillingUrlOrdersList, storeInstance);
                    if (!string.IsNullOrWhiteSpace(ordersUrl))
                    {
                        var ordersSource = new GenericList();
                        storeInstance.LoadURLSource(Constants.ORDERS_LIST, ordersSource);
                        ordersSource.Url = ordersUrl;
                        storeInstance.Sources.AddSource(Constants.ORDERS_LIST, ref ordersSource);
                    }
                }
                else
                {
                    RegisterDefaultSources(storeInstance);
                }

                DefaultCommandExecutionSequence = Constants.DEFAULT_COMMAND_EXECUTION_SEQUENCE;
            }
            catch (Exception ex)
            {
                storeInstance.PerformanceLog.LogError(Helper.FormatException(ex));
            }

            return storeInstance;
        }

        private void RegisterDefaultSources(MySourceStore store)
        {
            var sources = new (string id, URLSource src)[]
            {
                (Constants.ALL_RELEASE_LIST, new AllReleaseList()),
                (Constants.CIRCULARS_LIST, new GenericList()),
                (Constants.REPORTS_LIST, new GenericList()),
                (Constants.ORDERS_LIST, new GenericList()),
                (Constants.PRESS_RELEASE_LIST, new GenericList())
            };

            foreach (var (id, src) in sources)
            {
                store.LoadURLSource(id, src);
                store.Sources.AddSource(id, ref src);
            }
        }
    }
}


