﻿using System.Collections.Generic;

namespace IndiaSEBIDailyHeadlines
{
    internal static class TemplateData
    {
        public static Dictionary<string, bool> AllStoriesHeadlines { get; } = new Dictionary<string, bool>();
        public static Dictionary<string, bool> AllAlertText { get; } = new Dictionary<string, bool>();
    }
}
