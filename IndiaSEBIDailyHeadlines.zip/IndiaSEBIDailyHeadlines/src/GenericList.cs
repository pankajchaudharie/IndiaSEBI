using AutomationCore;
using System;

namespace IndiaSEBIDailyHeadlines
{
    public class ListSourceHandler : URLSource
    {
        public override void OnDataReceived(UrlPollStatus pollStatus)
        {
            var storeRef = (MySourceStore)Store;

            if (!pollStatus.IsRequestCompleted)
                return;

            if (!string.IsNullOrWhiteSpace(pollStatus.ContentString) && pollStatus.IsRequestCompleted)
            {
                try
                {
                    string docType = ResolveType(pollStatus.Source.ID);

                    var pageParser = new PageContentParser(pollStatus.ContentString);

                    var resultData = pageParser.ExtractData(storeRef.RunDate, docType);

                    if (resultData.Stories.Count > 0)
                    {
                        storeRef.HandleAndPublish(resultData, pollStatus);
                    }
                    else
                    {
                        pollStatus.ChunkAttempt.LogComment($"No data extracted from {pollStatus.Source.Url}");
                    }
                }
                catch (Exception ex)
                {
                    Store.AutomationClient.OperatorLog(ConfigHelper.FormatException(ex));
                }
            }
        }

        private string ResolveType(string id)
        {
            return id switch
            {
                Constants.REPORTS_LIST => Constants.REPORTS,
                Constants.CIRCULARS_LIST => Constants.CIRCULARS,
                Constants.PRESS_RELEASE_LIST => Constants.PRESSRELEASE,
                Constants.ORDERS_LIST => Constants.ORDERS,
                _ => string.Empty
            };
        }
    }
}
