using AutomationCore;
using System;


namespace IndiaSEBIDailyHeadlines
{
    public class ReleaseListSource : URLSource
    {
        public override void OnDataReceived(UrlPollStatus pollStatus)
        {
            if (!pollStatus.IsRequestCompleted)
                return;

            var storeRef = (MySourceStore)Store;

            if (!string.IsNullOrWhiteSpace(pollStatus.ContentString) && pollStatus.IsRequestCompleted)
            {
                try
                {
                    var extractor = new ReleaseTableExtractor(pollStatus.ContentString);
                    var extractedData = extractor.ExtractStories(storeRef.RunDate);

                    if (extractedData.Stories.Count > 0)
                    {
                        storeRef.HandleAndPublish(extractedData, pollStatus);
                    }
                    else
                    {
                        pollStatus.ChunkAttempt.LogComment($"No stories found for {pollStatus.Source.Url}");
                    }
                }
                catch (Exception ex)
                {
                    Store.AutomationClient.OperatorLog(ConfigHelper.FormatException(ex));
                }
            }
        }
    }


}
