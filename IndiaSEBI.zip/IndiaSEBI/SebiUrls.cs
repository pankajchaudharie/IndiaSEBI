public static class SebiUrls
{
    public const string MainListing = "https://www.sebi.gov.in/sebiweb/home/HomeAction.do?doListingAll=yes";
    public const string Circulars = "https://www.sebi.gov.in/sebiweb/home/HomeAction.do?doListing=yes&sid=1&ssid=7&smid=0";
    public const string Reports = "https://www.sebi.gov.in/sebiweb/home/HomeAction.do?doListing=yes&sid=4&ssid=38&smid=35";
    public const string Orders = "https://www.sebi.gov.in/sebiweb/home/HomeAction.do?doListing=yes&sid=2&ssid=9&smid=2";
    public const string PressReleases = "https://www.sebi.gov.in/sebiweb/home/HomeAction.do?doListing=yes&sid=6&ssid=23&smid=0";
}