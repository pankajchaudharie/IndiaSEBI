using System;
using System.Net.Http;
using System.Threading.Tasks;
using HtmlAgilityPack;

public static class MainListingFetcher
{
    public static async Task Fetch(string targetDate)
    {
        string url = SebiUrls.MainListing;
        using var httpClient = new HttpClient();
        var html = await httpClient.GetStringAsync(url);

        var doc = new HtmlDocument();
        doc.LoadHtml(html);

        Console.WriteLine("Main Listing:");
        var table = doc.DocumentNode.SelectSingleNode("//table[contains(@class, 'table')]");
        if (table == null)
        {
            Console.WriteLine("Table not found.");
            return;
        }

        foreach (var row in table.SelectNodes(".//tr"))
        {
            var cells = row.SelectNodes(".//td");
            if (cells == null || cells.Count < 3) continue;

            string date = cells[0].InnerText.Trim();
            string type = cells[1].InnerText.Trim();
            var titleNode = cells[2].SelectSingleNode(".//a");
            string title = titleNode?.InnerText.Trim() ?? "";
            string href = titleNode?.GetAttributeValue("href", "") ?? "";

            if (SebiHelper.IsMatchingDate(targetDate, date) &&
                Array.Exists(SebiConstants.AllowedTypes, t => t.Equals(type, StringComparison.OrdinalIgnoreCase)))
            {
                bool shouldStore = false;

                if (type.Equals("Circulars", StringComparison.OrdinalIgnoreCase))
                {
                    foreach (var keyword in SebiConstants.CircularKeywords)
                    {
                        if (title.IndexOf(keyword, StringComparison.OrdinalIgnoreCase) >= 0)
                        {
                            Console.WriteLine($"Date: {date}, Type: {type}, Title: {title}, Href: {href}");
                            shouldStore = true;
                            break;
                        }
                    }
                }
                else if (type.Equals("Press Releases", StringComparison.OrdinalIgnoreCase))
                {
                    foreach (var keyword in SebiConstants.PressReleaseKeywords)
                    {
                        if (title.IndexOf(keyword, StringComparison.OrdinalIgnoreCase) >= 0)
                        {
                            Console.WriteLine($"Date: {date}, Type: {type}, Title: {title}, Href: {href}");
                            shouldStore = true;
                            break;
                        }
                    }
                }
                else
                {
                    Console.WriteLine($"Date: {date}, Type: {type}, Title: {title}, Href: {href}");
                    shouldStore = true;
                }

                if (shouldStore)
                {
                    var record = new SebiRecord
                    {
                        Date = date,
                        Type = type,
                        Title = title,
                        Href = href
                    };
                    SebiDataStore.Records.Add(record);

                    if (type.Equals("Reports", StringComparison.OrdinalIgnoreCase) ||
                        type.Equals("Orders", StringComparison.OrdinalIgnoreCase))
                    {
                        SebiDataStore.Stories.Add(new Story(record));
                        SebiDataStore.Alerts.Add(new Alerts(record));
                    }
                    else if (type.Equals("Circulars", StringComparison.OrdinalIgnoreCase))
                    {
                        SebiDataStore.Alerts.Add(new Alerts(record));
                    }
                    else if (type.Equals("Press Releases", StringComparison.OrdinalIgnoreCase))
                    {
                        SebiDataStore.Stories.Add(new Story(record));
                    }
                }
            }
        }
    }
}