public class SebiRecord
{
    public string Date { get; set; }
    public string Type { get; set; }
    public string Title { get; set; }
    public string Href { get; set; }
}