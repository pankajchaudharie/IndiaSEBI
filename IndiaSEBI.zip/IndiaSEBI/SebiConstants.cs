public static class SebiConstants
{
    public const string FORCE_FILLING_DATE = "06-05-2025"; // MM-DD-YYYY format

    public static readonly string[] AllowedTypes = { "Reports", "Press Releases", "Orders", "Circulars" };

    public static readonly string[] CircularKeywords = {
        "ESG", "Equity Derivatives", "REITs", "InvITs", "FPIs", "AIFs", "Foreign Portfolio Investors",
        "Listing Obligations and", "Disclosure Requirements", "Mutual Funds", "Asset Management Company",
        "Funds", "Fund", "Relaxation", "Algorithmic Trading", "Offshore Derivative Instruments", "ODIs",
        "Bonds", "Bond", "Debt", "Trading", "Credit Default Swaps", "CDS", "Credit Rating Agencies",
        "CRAs", "Market Infrastructure Institutions", "MII", "MIIs", "Initial Public Offer", "Modification",
        "OFS", "Introduction", "Stock Brokers", "Derivative", "Derivatives", "Listed Entities", "Extension",
        "Measures", "Investment", "Futures", "Commodities", "Commodity"
    };

    public static readonly string[] PressReleaseKeywords = {
        "Study", "statement", "SEBI Board Meting", "Commodity Derivatives Segment", "Commodities",
        "Commodity", "Clarification", "Clarifies", "Advisory", "FPI", "FPIs", "Foreign Portfolio Investors",
        "Annual Report", "Working Group", "Working Groups", "Whole Time Member", "Chairperson", "Chairman",
        "Mandates", "Disclosure", "Analysis", "Consultation Paper", "Committee", "Issues", "Allows",
        "Search and seizure", "Conducts", "Constitutes", "Directions", "Recognition", "Unregulated",
        "Circular", "Seeks report", "Appointment", "Discussion Paper"
    };
}