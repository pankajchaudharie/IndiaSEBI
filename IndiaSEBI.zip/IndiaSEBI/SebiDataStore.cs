using System.Collections.Generic;

public static class SebiDataStore
{
    public static List<SebiRecord> Records { get; } = new List<SebiRecord>();
    public static List<Story> Stories { get; } = new List<Story>();
    public static List<Alerts> Alerts { get; } = new List<Alerts>();

    // You can keep other properties/methods as needed
}