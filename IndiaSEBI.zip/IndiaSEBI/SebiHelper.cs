using System;
using System.Globalization;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using HtmlAgilityPack;

public static class SebiHelper
{

    // Current date in MM-DD-YYYY format
    public static string CurrentDate => DateTime.Now.ToString("MM-dd-yyyy");

    // Checks if input date (MM-DD-YYYY) matches SEBI date (MMM dd, yyyy)
    public static bool IsMatchingDate(string inputDateMMDDYYYY, string sebiDateString)
    {
        if (!DateTime.TryParseExact(inputDateMMDDYYYY, "MM-dd-yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime inputDate))
            return false;

        if (!DateTime.TryParseExact(sebiDateString, "MMM dd, yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime sebiDate))
            return false;

        return inputDate.Date == sebiDate.Date;
    }

    // Example: Normalize title string (can be extended for other utilities)
    public static string NormalizeTitle(string title)
    {
        return title?.Trim().ToLowerInvariant() ?? string.Empty;
    }

    public static void AddRecord(
        SebiRecord record,
        List<Story> stories,
        List<Alerts> alerts)
    {
        switch (record.Type)
        {
            case "Reports":
            case "Orders":
                stories.Add(new Story(record));
                alerts.Add(new Alerts(record));
                break;
            case "Circulars":
                alerts.Add(new Alerts(record));
                break;
            case "Press Releases":
                stories.Add(new Story(record));
                break;
        }
    }

    public static async Task FetchPaginatedMainListing(string targetDate)
    {
        int page = 1;
        int doDirect = 0;
        bool hasMorePages = true;

        while (hasMorePages)
        {
            var payload = new Dictionary<string, string>
            {
                { "nextValue", page.ToString() },
                { "next", "n" },
                { "search", "" },
                { "fromDate", "" },
                { "toDate", "" },
                { "deptId", "-1" },
                { "sid", "-1" },
                { "ssid", "-1" },
                { "smid", "-1" },
                { "cid", "-1" },
                { "sText", "-- All Section --" },
                { "ssText", "-- All Sub Section --" },
                { "smText", "-- All Sub Section List --" },
                { "cText", "-- All Info for --" },
                { "doDirect", doDirect.ToString() }
            };

            using var httpClient = new HttpClient();
            var content = new FormUrlEncodedContent(payload);
            var response = await httpClient.PostAsync("https://www.sebi.gov.in/sebiweb/ajax/home/getnewslistallinfo.jsp", content);
            var html = await response.Content.ReadAsStringAsync();

            var doc = new HtmlDocument();
            doc.LoadHtml(html);

            var table = doc.DocumentNode.SelectSingleNode("//table[contains(@class, 'table')]");
            if (table == null)
            {
                break;
            }

            bool foundRecord = false;
            foreach (var row in table.SelectNodes(".//tr"))
            {
                var cells = row.SelectNodes(".//td");
                if (cells == null || cells.Count < 3) continue;

                string date = cells[0].InnerText.Trim();
                string type = cells[1].InnerText.Trim();
                var titleNode = cells[2].SelectSingleNode(".//a");
                string title = titleNode?.InnerText.Trim() ?? "";
                string href = titleNode?.GetAttributeValue("href", "") ?? "";

                if (IsMatchingDate(targetDate, date) &&
                    Array.Exists(SebiConstants.AllowedTypes, t => t.Equals(type, StringComparison.OrdinalIgnoreCase)))
                {
                    foundRecord = true;
                    var record = new SebiRecord
                    {
                        Date = date,
                        Type = type,
                        Title = title,
                        Href = href
                    };
                    SebiDataStore.Records.Add(record);

                    // Business logic for Stories and Alerts
                    if (type.Equals("Reports", StringComparison.OrdinalIgnoreCase) ||
                        type.Equals("Orders", StringComparison.OrdinalIgnoreCase))
                    {
                        SebiDataStore.Stories.Add(new Story(record));
                        SebiDataStore.Alerts.Add(new Alerts(record));
                    }
                    else if (type.Equals("Circulars", StringComparison.OrdinalIgnoreCase))
                    {
                        SebiDataStore.Alerts.Add(new Alerts(record));
                    }
                    else if (type.Equals("Press Releases", StringComparison.OrdinalIgnoreCase))
                    {
                        SebiDataStore.Stories.Add(new Story(record));
                    }
                }
            }

            // Stop if no records found on this page (optional, or you can set a max page limit)
            if (!foundRecord)
                hasMorePages = false;

            // Prepare for next page
            page++;
            doDirect++;
        }
    }

    // Add more SEBI-specific helper methods here as needed
}