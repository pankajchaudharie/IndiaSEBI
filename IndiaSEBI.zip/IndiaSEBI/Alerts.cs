public class Alerts
{
    public string AlertTitle { get; set; } // Title
    public string Type { get; set; }       // Type (e.g., "Orders", "Reports", "Circulars")

    public Alerts(SebiRecord record)
    {
        AlertTitle = record.Title;
        Type = record.Type;
    }
}   