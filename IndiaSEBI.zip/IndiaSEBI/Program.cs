﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using HtmlAgilityPack;

class Program
{
    static async Task Main(string[] args)
    {
        // Set to true to use today's date, false to use forced date
        bool isCurrentDate = false;

        string targetDate = isCurrentDate
            ? SebiHelper.CurrentDate
            : SebiConstants.FORCE_FILLING_DATE;
        //await SebiHelper.FetchPaginatedMainListing("07-17-2025");

        if (isCurrentDate)
        {
            await MainListingFetcher.Fetch(targetDate);
            //await SebiHelper.FetchPaginatedMainListing(targetDate);

        }
        else
        {
            await CircularsFetcher.Fetch(targetDate);
            await ReportsFetcher.Fetch(targetDate);
            await OrdersFetcher.Fetch(targetDate);
            await PressReleasesFetcher.Fetch(targetDate);
        }

        Console.WriteLine("Ready to inspect SebiDataStore.Records");
    }
}