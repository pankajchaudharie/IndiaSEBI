using System;
using System.Net.Http;
using System.Threading.Tasks;
using HtmlAgilityPack;

public static class OrdersFetcher
{
    public static async Task Fetch(string targetDate)
    {
        string url = SebiUrls.Orders;
        using var httpClient = new HttpClient();
        var html = await httpClient.GetStringAsync(url);

        var doc = new HtmlDocument();
        doc.LoadHtml(html);

        Console.WriteLine("Orders:");
        var table = doc.DocumentNode.SelectSingleNode("//table[contains(@class, 'table')]");
        if (table == null)
        {
            Console.WriteLine("Table not found.");
            return;
        }

        foreach (var row in table.SelectNodes(".//tr"))
        {
            var cells = row.SelectNodes(".//td");
            if (cells == null || cells.Count < 2) continue;

            string date = cells[0].InnerText.Trim();
            var titleNode = cells[1].SelectSingleNode(".//a");
            string title = titleNode?.InnerText.Trim() ?? "";
            string href = titleNode?.GetAttributeValue("href", "") ?? "";

            if (SebiHelper.IsMatchingDate(targetDate, date))
            {
                Console.WriteLine($"Date: {date}, Title: {title}, Href: {href}");
                var record = new SebiRecord
                {
                    Date = date,
                    Type = "Orders",
                    Title = title,
                    Href = href
                };
                SebiDataStore.Records.Add(record);
                SebiHelper.AddRecord(record, SebiDataStore.Stories, SebiDataStore.Alerts);
            }
        }
    }
}