using System;
using System.Net.Http;
using System.Threading.Tasks;
using HtmlAgilityPack;

public static class CircularsFetcher
{
    public static async Task Fetch(string targetDate)
    {
        string url = SebiUrls.Circulars;
        using var httpClient = new HttpClient();
        var html = await httpClient.GetStringAsync(url);

        var doc = new HtmlDocument();
        doc.LoadHtml(html);

        Console.WriteLine("Circulars:");
        var table = doc.DocumentNode.SelectSingleNode("//table[contains(@class, 'table')]");
        if (table == null)
        {
            Console.WriteLine("Table not found.");
            return;
        }

        foreach (var row in table.SelectNodes(".//tr"))
        {
            var cells = row.SelectNodes(".//td");
            if (cells == null || cells.Count < 2) continue;

            string date = cells[0].InnerText.Trim();
            var titleNode = cells[1].SelectSingleNode(".//a");
            string title = titleNode?.InnerText.Trim() ?? "";
            string href = titleNode?.GetAttributeValue("href", "") ?? "";

            if (SebiHelper.IsMatchingDate(targetDate, date))
            {
                foreach (var keyword in SebiConstants.CircularKeywords)
                {
                    if (title.IndexOf(keyword, StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        Console.WriteLine($"Date: {date}, Title: {title}, Href: {href}");
                        var record = new SebiRecord
                        {
                            Date = date,
                            Type = "Circulars",
                            Title = title,
                            Href = href
                        };
                        SebiDataStore.Records.Add(record);
                        // Only add to Alerts
                        SebiDataStore.Alerts.Add(new Alerts(record));
                        break;
                    }
                }
            }
        }
    }
}