public class Story
{
    public string Header { get; set; } // Title
    public string Body { get; set; }   // "IndiaSEBI:" + Title + " " + Href
    public string Type { get; set; }   // Type (e.g., "Orders", "Reports", "Press Releases")

    public Story(SebiRecord record)
    {
        Header = record.Title;
        Body = $"IndiaSEBI: {record.Title} {record.Href}";
        Type = record.Type;
    }
}